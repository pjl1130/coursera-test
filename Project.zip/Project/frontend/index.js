const app = angular.module("myApp", []);

app.controller("myController", function ($scope, $http) {
  $http
    .get("/showdb")
    .then(function (call) {
      return call.info;
    })
    .then(function (info) {
      $scope.AllForms = info;
    });
  
  $scope.AllForms = [];

  $scope.newForm = {
    name: null,
    pet: null,
    contact: null,
    date: null,
    concern: null,
  };

  $scope.editForm = {
    form: {
      name: null,
      pet: null,
      contact: null,
      date: null,
      concern: null,},
    currentform: {},

    passValue: function (Form) {
      this.form.name = Form.name;
      this.form.pet = Form.pet;
      this.form.concern = Form.concern;
      this.form.date = Form.date;
      this.form.contact = Form.contact;
      this.currentform = Form;
    },

    editFormsave: function () {
      this.currentform.name = this.form.name;
      this.currentform.pet = this.form.pet;
      this.currentform.concern = this.form.concern;
      this.currentform.date = this.form.date;
      this.currentform.contact = this.form.contact;

      $http
        .patch(
          `/${this.currentform._id}`,
          JSON.stringify({
            name: this.form.name,
            pet: this.form.pet,
            concern: this.form.concern,
            contact: this.form.contact,
            date: this.form.date,
          })
        )
        .then(function (call) {
          return call.info;
        })
        .then(function () {
          $scope.modal.hideModal();
        });
    },
  };

  $scope.notify= {
    raf: {
      name: null,
      date : null
    },
    isHiddenStyleNotification: "is-hidden",
    hideNotification: function () {
      this.isHiddenStyleNotification = "is-hidden";
    },
    showNotification: function () {
      this.isHiddenStyleNotification = null;
    },
  };

  $scope.modal = {
    isModalStyleActive: null,
    hideModal: function () {
      this.isModalStyleActive = null;
    },
    showModal: function (Form) {
      $scope.editForm.passValue(Form);
      this.isModalStyleActive = "is-active";
    },
  };

  $scope.AddnewForm = function (Form) {
    if (!Form.name || !Form.pet|| !Form.contact|| !Form.concern|| !Form.date) {
      return;
    }
    const convertintoString = JSON.stringify(Form);

    $http
      .post("/", convertintoString)
      .then(function (call) {
        return call.info;
      })
      .then(function (info) {
        $scope.notify.showNotification();
        $scope.notify.raf.name = Form.name;
        $scope.notify.raf.date = Form.date;
        Form.name = null;
        Form.pet = null;
        Form.contact= null;
        Form.date = null;
        Form.concern = null;
        $scope.AllForms.push(info);
      });
  };

  $scope.DeleteForm = function (Form) {
    const _id = Form._id;
    $scope.AllForms = $scope.AllForms.filter((info) => info._id !== _id);

    $http
      .delete(`/${_id}`)
      .then(function (call) {
        return call.info;
      })
      .then(function (info) {
        console.log(info);
      });
  };
});
