require("./Connect");
const express = require("express");
const mongoose = require("mongoose");
const path = require("path");

const app = express();
const Info = require("./Info");
const frontend = path.join(__dirname, "../frontend/");

app.use(express.static(frontend));
app.use(express.json());

app.get("/showdb", async (req, res) => {
  try {
    const info = await Info.find();
    res.status(200).send(info);
  } catch (error) {
    res.status(408).send();
  }
});

app.post("/", async (req, res) => {
  const {name,
        pet,
        contact,
        concern,
        date } = req.body;

  try {
    const info = new Info(
      { name: name,
        concern: concern,
        pet: pet,
        date:date,
        contact:contact });

    await info.save();
    res.status(201).send(info);
  } catch (error) {
    res.status(400).send(error.message);
  }
});

app.patch("/:_id", async (req, res) => {
  const { _id } = req.params;
  const {name, pet, contact, concern , date } = req.body;

  try {
    
    const Updateid = mongoose.Types.ObjectId(_id);

    const info = await Info.findByIdAndUpdate(
      Updateid,
      {
        name: name,
        concern: concern,
        pet: pet,
        date:date,
        contact:contact
      },
      { new: true, lean: true }
    );

    res.status(200).send(info);
  } catch (error) {
    res.status(400).send(error.message);
  }
});

app.delete("/:_id", async (req, res) => {
  const { _id } = req.params;
  try {
    const Deleteid = mongoose.Types.ObjectId(_id);
    const DeleteInfo = await Info.findByIdAndDelete(Deleteid);
    res.status(200).send(DeleteInfo);
  } catch (error) {
    res.status(400).send(error.message);
  }
});

app.get("*", (req, res) => {
  res.status(200).sendFile(`${frontend}/index.html`);
});


app.listen(3000, console.log(3000));
