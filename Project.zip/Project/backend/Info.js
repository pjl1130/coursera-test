
const mongoose = require("mongoose");


const Info = new mongoose.Schema(
  {
   
    name: {
      type: String,
      require: true,
    },
    pet: {
      type: String,
      require: true,
    },
    contact: {
      type: Number,
      require: true,
    },
    concern: {
      type: String,
      require: true,
    },
    date : {
      type: String,
      require: true,
    }
  }
);

const RegInfo = mongoose.model("RegInfo", Info);
module.exports = RegInfo;
